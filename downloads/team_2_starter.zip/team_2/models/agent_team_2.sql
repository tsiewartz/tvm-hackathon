{#- Team 2 agent. Uses your semantic view as its only data tool.
    cowork: only if the account has a CoWork object (ask the facilitator), set it to its name,
    e.g. 'SNOWFLAKE_INTELLIGENCE_OBJECT_DEFAULT', so the agent shows up in Snowflake CoWork.  -#}
{%- set cowork = none -%}
{{ config(
    materialized='cortex_agent',
    meta={
      'display_name': 'Team 2 agent',
      'comment': 'Team 2: TODO business question',
      'cowork_object': cowork
    }
) }}
models:
  orchestration: auto
orchestration:
  budget:
    seconds: 60
    tokens: 20000
instructions:
  response: "Answer concisely for a TVM business user. Lead with the number, then one sentence of context. Always mention the period you used."
  orchestration: "Use the data tool for every question about the data. If a question is ambiguous about time, ask or use the last 12 months and say so."
  sample_questions:
    - question: "TODO: your first golden question"
tools:
  - tool_spec:
      type: "cortex_analyst_text_to_sql"
      name: "data"
      description: "TODO: what this data covers, in business words (which brand, which markets, which period)"
  - tool_spec:
      type: "data_to_chart"
      name: "data_to_chart"
      description: "Generates charts from query results"
tool_resources:
  data:
    semantic_view: "{{ ref('sv_team_2') }}"
    execution_environment:
      type: warehouse
      warehouse: "{{ target.warehouse }}"
      query_timeout: 120
