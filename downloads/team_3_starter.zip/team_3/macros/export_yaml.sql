{#
  Print a semantic view or agent that was built in the Snowsight UI as a ready-to-paste dbt model.

    dbt run-operation export_yaml --args "{name: MY_DB.HACK_TEAM_1.SV_TEAM_1_DRAFT}"
    dbt run-operation export_yaml --args "{name: MY_DB.HACK_TEAM_1.MY_UI_AGENT, kind: agent}"

  Tables that are dbt sources or models become {{ base_table(source(...)) }} / ref(...),
  an agent's semantic view becomes {{ ref(...) }} and its warehouse {{ target.warehouse }},
  so the pasted model keeps dbt lineage and works in every target.
#}
{% macro export_yaml(name, kind='semantic_view') %}
  {%- set by_name = {} -%}
  {%- for s in graph.sources.values() -%}
    {%- do by_name.update({(s.database ~ '.' ~ s.schema ~ '.' ~ s.identifier) | upper:
                           "source('" ~ s.source_name ~ "', '" ~ s.name ~ "')"}) -%}
  {%- endfor -%}
  {%- for n in graph.nodes.values() if n.resource_type in ('model', 'seed', 'snapshot') -%}
    {%- do by_name.update({(n.database ~ '.' ~ n.schema ~ '.' ~ (n.alias or n.name)) | upper:
                           "ref('" ~ n.name ~ "')"}) -%}
  {%- endfor -%}
  {%- set tokens = {} -%}

  {%- if kind == 'semantic_view' -%}
    {%- set y = run_query("select system$read_yaml_from_semantic_view('" ~ name ~ "')").columns[0].values()[0] -%}
    {%- set spec = fromyaml(y) -%}
    {%- do spec.pop('name', none) -%}
    {%- for t in spec.get('tables', []) -%}
      {%- set bt = t.get('base_table') or {} -%}
      {%- set key = (bt.get('database', '') ~ '.' ~ bt.get('schema', '') ~ '.' ~ bt.get('table', '')) | upper -%}
      {%- if key in by_name -%}
        {%- set tok = '__DBT_TABLE_' ~ loop.index ~ '__' -%}
        {%- do tokens.update({tok: '{{ base_table(' ~ by_name[key] ~ ') }}'}) -%}
        {%- do t.update({'base_table': tok}) -%}
      {%- endif -%}
    {%- endfor -%}
    {%- set header = "{{ config(materialized='semantic_view_yaml') }}" -%}

  {%- elif kind == 'agent' -%}
    {%- set d = run_query('describe agent ' ~ name) -%}
    {%- set row = d.rows[0] -%}
    {%- set spec = fromjson(row['agent_spec']) -%}
    {%- for tool, res in (spec.get('tool_resources') or {}).items() -%}
      {%- if res.get('semantic_view') and (res['semantic_view'] | upper) in by_name -%}
        {%- set tok = '__DBT_SV_' ~ loop.index ~ '__' -%}
        {%- do tokens.update({tok: '"{{ ' ~ by_name[res['semantic_view'] | upper] ~ ' }}"'}) -%}
        {%- do res.update({'semantic_view': tok}) -%}
      {%- endif -%}
      {%- set env = res.get('execution_environment') or {} -%}
      {%- if env.get('warehouse') -%}
        {%- do tokens.update({'__DBT_WH__': '"{{ target.warehouse }}"'}) -%}
        {%- do env.update({'warehouse': '__DBT_WH__'}) -%}
      {%- endif -%}
    {%- endfor -%}
    {%- set profile = fromjson(row['profile'] or '{}') -%}
    {%- set header = "{{ config(materialized='cortex_agent', meta={'display_name': '" ~ (profile.get('display_name') or '') | replace("'", "\\'")
                     ~ "', 'comment': '" ~ (row['comment'] or '') | replace("'", "\\'") ~ "'}) }}" -%}

  {%- else -%}
    {{ exceptions.raise_compiler_error("kind must be 'semantic_view' or 'agent'") }}
  {%- endif -%}

  {%- set out = namespace(body=toyaml(spec)) -%}
  {%- for tok, val in tokens.items() -%}
    {%- set out.body = out.body | replace(tok, val) -%}
  {%- endfor -%}
  {{ print('\n----- paste everything below into your model file -----\n' ~ header ~ '\n' ~ out.body ~ '----- end -----') }}
{% endmacro %}
