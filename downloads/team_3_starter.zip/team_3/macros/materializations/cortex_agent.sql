{#
  Custom materialization: Snowflake Cortex Agent as a dbt model.
  The model body is the agent specification YAML. Use {{ ref('sv_...') }} inside it
  so the agent sits downstream of its semantic view in the DAG.

  Configs (under config meta={...}):
    display_name   (str)   shown in Snowflake CoWork
    comment        (str)
    grant_usage_to (list)  roles that may run the agent
    cowork_object  (str)   optional: name of the account's Snowflake CoWork object
                           (e.g. SNOWFLAKE_INTELLIGENCE_OBJECT_DEFAULT). Only needed if the
                           account curates agents with a CoWork object; requires MODIFY on it.
#}
{% materialization cortex_agent, adapter='snowflake' %}
  {%- set _m = config.get('meta') or {} -%}
  {%- set target_relation = api.Relation.create(
        database=model.database, schema=model.schema,
        identifier=model.alias, type='view') -%}
  {%- set display_name = _m.get('display_name', model.alias) -%}
  {%- set comment = _m.get('comment', 'Managed by dbt') -%}
  {%- set profile_json = tojson({'display_name': display_name}) -%}

  {{ run_hooks(pre_hooks) }}

  {% call statement('main') -%}
    create or replace agent {{ target_relation }}
      comment = '{{ comment | replace("'", "''") }}'
      profile = '{{ profile_json }}'
      from specification
    $${{ sql }}$$
  {%- endcall %}

  {% for role in _m.get('grant_usage_to', []) %}
    {% call statement('grant_' ~ loop.index) -%}
      grant usage on agent {{ target_relation }} to role {{ role }}
    {%- endcall %}
  {% endfor %}

  {%- set cowork = _m.get('cowork_object') -%}
  {% if cowork %}
    {# membership survives CREATE OR REPLACE AGENT; ADD fails if already present, so tolerate only that #}
    {% call statement('cowork_add') -%}
      execute immediate $$
      begin
        alter snowflake intelligence {{ cowork }} add agent {{ target_relation }};
        return 'added';
      exception
        when other then
          if (contains(:sqlerrm, 'already present')) then
            return 'already present';
          end if;
          raise;
      end;
      $$
    {%- endcall %}
  {% endif %}

  {{ run_hooks(post_hooks) }}
  {{ return({'relations': [target_relation]}) }}
{% endmaterialization %}
