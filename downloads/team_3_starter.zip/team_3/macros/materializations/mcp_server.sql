{#
  Custom materialization: Snowflake-managed MCP server as a dbt model.
  The model body is the MCP server specification YAML (tools: ...).
  Use {{ ref() }} for semantic views / agents exposed as tools.

  Configs (under config meta={...}):
    grant_usage_to (list)  roles that may connect to the server
#}
{% materialization mcp_server, adapter='snowflake' %}
  {%- set _m = config.get('meta') or {} -%}
  {%- set target_relation = api.Relation.create(
        database=model.database, schema=model.schema,
        identifier=model.alias, type='view') -%}

  {{ run_hooks(pre_hooks) }}

  {% call statement('main') -%}
    create or replace mcp server {{ target_relation }}
      from specification
    $${{ sql }}$$
  {%- endcall %}

  {% for role in _m.get('grant_usage_to', []) %}
    {% call statement('grant_' ~ loop.index) -%}
      grant usage on mcp server {{ target_relation }} to role {{ role }}
    {%- endcall %}
  {% endfor %}

  {{ run_hooks(post_hooks) }}
  {{ return({'relations': [target_relation]}) }}
{% endmaterialization %}
