{#
  Custom materialization: Snowflake semantic view from YAML, as a dbt model.
  The model body is a semantic view YAML specification, the same format that
  Semantic Studio / Autopilot show and that `dbt run-operation export_yaml` prints.

  - `name:` in the YAML is ignored: the view is always named after the model.
  - Use {{ base_table(source('tvm_marts', 'my_table')) }} or {{ base_table(ref('my_model')) }}
    as the value of `base_table:` to keep dbt lineage instead of hard-coded names.
  - Grants on an existing view are kept (the procedure copies grants on replace).
#}
{% materialization semantic_view_yaml, adapter='snowflake' %}
  {%- set target_relation = api.Relation.create(
        database=model.database, schema=model.schema,
        identifier=model.alias, type='view') -%}
  {%- set spec = fromyaml(sql) -%}
  {%- if spec is not mapping or 'tables' not in spec -%}
    {{ exceptions.raise_compiler_error("Model " ~ model.name ~ " must contain a semantic view YAML specification with a `tables:` list.") }}
  {%- endif -%}
  {%- do spec.update({'name': model.alias | upper}) -%}

  {{ run_hooks(pre_hooks) }}

  {% call statement('main') -%}
    call system$create_semantic_view_from_yaml(
      '{{ target_relation.database }}.{{ target_relation.schema }}',
      $${{ toyaml(spec) }}$$
    )
  {%- endcall %}

  {{ run_hooks(post_hooks) }}
  {{ return({'relations': [target_relation]}) }}
{% endmaterialization %}


{# Renders a relation as a YAML base_table mapping and records the dbt dependency. #}
{% macro base_table(relation) -%}
{database: {{ relation.database }}, schema: {{ relation.schema }}, table: {{ relation.identifier }}}
{%- endmacro %}
