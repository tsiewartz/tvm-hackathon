{#- Team 3 MCP server. Exposes your agent to Claude Code. Nothing to change here. -#}
{{ config(materialized='mcp_server') }}
tools:
  - name: "team-3-agent"
    type: "CORTEX_AGENT_RUN"
    identifier: "{{ ref('agent_team_3') }}"
    title: "Team 3 agent"
    description: "Ask a business question about TODO. Returns an answer with the SQL used."
    annotations: { readOnlyHint: true, destructiveHint: false, openWorldHint: false }
