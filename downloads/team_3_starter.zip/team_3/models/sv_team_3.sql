{#- Team 3 semantic view (YAML, the same format Semantic Studio shows). Start small, build it, ask it, then grow.
    Fill in the 4 lines below (look at the table under Databases first), then build.
    Why the date and number column? A semantic view with only COUNT(*) is too thin:
    Cortex Analyst needs at least one dimension and one fact to write good SQL.          -#}
{%- set mart_table    = 'my_mart_table' -%}    {# a table listed in models/_marts_sources.yml #}
{%- set row_is        = 'TODO: what one row is, e.g. one subscriber per month' -%}
{%- set date_column   = 'my_date_column' -%}   {# e.g. month_start #}
{%- set amount_column = 'my_number_column' -%} {# e.g. mrr_eur #}

{{ config(materialized='semantic_view_yaml') }}
description: 'Team 3: TODO your business question'
tables:
  - name: MART
    description: "{{ row_is }}"
    base_table: {{ base_table(source('tvm_marts', mart_table)) }}
    dimensions:
      - name: PERIOD
        synonyms: ['date', 'month']
        description: 'TODO: what the date means'
        expr: mart.{{ date_column }}
      # next: the columns people filter and group by, with business names, e.g.
      # - name: COUNTRY
      #   description: 'SE = Sweden, FI = Finland'
      #   expr: mart.country
    facts:
      - name: AMOUNT
        description: 'TODO: what the number is, unit and currency'
        expr: mart.{{ amount_column }}
    metrics:
      - name: ROW_COUNT
        description: 'Number of rows'
        expr: COUNT(*)
      - name: TOTAL_AMOUNT
        description: 'TODO: your first real KPI, e.g. total MRR in EUR'
        expr: SUM(mart.amount)
